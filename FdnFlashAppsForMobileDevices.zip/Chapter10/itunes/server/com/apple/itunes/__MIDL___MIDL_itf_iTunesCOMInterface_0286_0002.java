/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0286_0002 {

	public static final int ITVideoKindNone = 0;
	public static final int ITVideoKindMovie = 1;
	public static final int ITVideoKindMusicVideo = 2;
	public static final int ITVideoKindTVShow = 3;
}
