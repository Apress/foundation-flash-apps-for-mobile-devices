/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0278_0001 {

	public static final int ITPlaylistKindUnknown = 0;
	public static final int ITPlaylistKindLibrary = 1;
	public static final int ITPlaylistKindUser = 2;
	public static final int ITPlaylistKindCD = 3;
	public static final int ITPlaylistKindDevice = 4;
	public static final int ITPlaylistKindRadioTuner = 5;
}
