/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public class iTunesConvertOperationStatus extends IITConvertOperationStatus {

	public static final String componentName = "iTunesLib.iTunesConvertOperationStatus";

	public iTunesConvertOperationStatus() {
		super(componentName);
	}

	public iTunesConvertOperationStatus(Dispatch d) {
		super(d);
	}
}
