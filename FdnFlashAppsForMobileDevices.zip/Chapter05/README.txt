Chapter 5: Application Development

Inside this folder you will find several examples illustrating the concepts 
behind application development in Flash Lite 1.1 and 2.X.

The majority of these examples were designed to run on the Symbian standalone 
player device profile. They may work in other situations but when testing 
please be sure to select this profile if possible.

With the LoadVariables.fla and LoadVariablesDB.fla examples please be 
sure to copy the relevant data text files along with the SWF when testing on 
a device.

With the StockQuote application example you will need to be running a local
webserver as described in the chapter itself. Code for various types of 
server can be found in the "server side" sub-folder.

NOTE: The samples are designed to run in the Flash Lite player (either on a 
device or in the Flash MX 2004 Professional or Flash 8 Professional IDE). For 
this reason certain functionality may not work when run in the web browser 
plugin or standalone desktop Flash Player.