Chapter 3: Flash Lite 1.1

Inside this folder you will find several examples designed to illustrate the 
core concepts behind Flash Lite 1.1 development.

Pay special attention to the StringFunctions.fla example. This will not display
anything on screen. Instead refer to the section on "String Functions" in 
Chapter 3 to find out how to view this example.

NOTE: The samples are designed to run in the Flash Lite player (either on a 
device or in the Flash MX 2004 Professional or Flash 8 Professional IDE). For 
this reason certain functionality may not work when run in the web browser 
plugin or standalone desktop Flash Player.