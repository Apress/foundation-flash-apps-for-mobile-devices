Chapter 4: Flash Lite 2.X

Inside this folder you will find several examples designed to illustrate the 
core concepts behind Flash Lite 2.X development and ActionScript 2.0.

The majority of these examples were designed to run on the Symbian standalone 
player device profile. They may work in other situations but when testing 
please be sure to select this profile if possible.

N.B. Remember to copy the sample .3gp file along with the SWF when running the 
3GPTest.fla example on your mobile device in order to see the video playback.

NOTE: The samples are designed to run in the Flash Lite player (either on a 
device or in the Flash MX 2004 Professional or Flash 8 Professional IDE). For 
this reason certain functionality may not work when run in the web browser 
plugin or standalone desktop Flash Player.