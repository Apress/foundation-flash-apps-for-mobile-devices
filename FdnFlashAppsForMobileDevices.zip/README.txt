The majority of these samples are designed to run in the Flash Lite player 
(either on a device or in the Flash MX 2004 Professional or Flash 8 
Professional IDE). 

For this reason certain functionality may not work when run in the web 
browser plugin or standalone Flash Player (such as date and time functions 
for instance).