Before you can compile this project you need to download some required files
from the Microsoft website at: http://msdn2.microsoft.com/en-us/library/aa446515.aspx

Beside of that the above article is a good read, and the technique is used by the
project for embedding the Flash Player ActiveX control in our .NET Compact Framework 2.0 project.