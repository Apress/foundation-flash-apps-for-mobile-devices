/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0267_0004 {

	public static final int ITPlayButtonStatePlayDisabled = 0;
	public static final int ITPlayButtonStatePlayEnabled = 1;
	public static final int ITPlayButtonStatePauseEnabled = 2;
	public static final int ITPlayButtonStatePauseDisabled = 3;
	public static final int ITPlayButtonStateStopEnabled = 4;
	public static final int ITPlayButtonStateStopDisabled = 5;
}
