// INCLUDE FILES
#include "FlashLauncher.h"

// UID for the application;
const TUid KUidFlashLauncher = { 0x10005B91 };

CApaDocument* CFlashLauncherApp::CreateDocumentL() {
    // Create an HelloWorldBasic document, and return a pointer to it
    return (static_cast<CApaDocument*>
                    ( CFlashLauncherDocument::NewL( *this ) ) );
}

TUid CFlashLauncherApp::AppDllUid() const {
    // Return the UID for the HelloWorldBasic application
    return KUidFlashLauncher;
}