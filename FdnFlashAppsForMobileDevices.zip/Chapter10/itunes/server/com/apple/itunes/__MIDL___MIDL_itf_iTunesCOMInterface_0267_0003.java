/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0267_0003 {

	public static final int ITCOMDisabledReasonOther = 0;
	public static final int ITCOMDisabledReasonDialog = 1;
	public static final int ITCOMDisabledReasonQuitting = 2;
}
