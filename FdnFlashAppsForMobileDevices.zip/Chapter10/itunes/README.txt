REQUIREMENTS
------------

 * Apple iTunes for Windows (www.apple.com/itunes)
 * Java Software Development Kit (java.sun.com)
 * Eclipse (easiest)
 * Jacob and Jacobgen version 0.7 (http://sourceforge.net/projects/jacob-project/)

INSTRUCTIONS
------------
	
After you have download and installed the tools listed above you are able to compile and/or
start with creating the iTunes example as discussed in the book. Before you can import
the ITunes object using the jacobgen utilty you first need to fix the run_jacobgen batch file
which can be found in the docs subdirectory. You should change the following defined variables
to locations which are valid for your computer:

	* JAVA_HOME
	* JACOBGEN_HOME

After this is succesfull you should be able to succesfully start the run_jacobgen batchfile 
(which can be found in the docs directory) via the command-line prompt you should expect out 
similar too:
	
  JacobGen [options] typelibfile
  
  Options:
          -package:<destination package name>
          -destdir:<root dir for classes>
          -listfile:<listing file>

   Press any key to continue . . .

This means it should work nicely, you can now try to import or create the required classes from
the ITunes COM Object. The command for this is:


   run_jacobgen.bat -destdir:"..\.." -listfile:"jacobgenlog.txt" -package:com.apple.itunes "C:\Program Files\iTunes\iTunes.exe"

The above command will create the apporiate java classes for communicating with iTunes using jacob, 
the above command will create the files in two directory up. You might want to edit to your liking.

Now when the code is generated you should copy the generated files, which are stored in 
the "com"-directory to  the Eclipse project directory. Once this is done you should be able 
to open and compile the project.