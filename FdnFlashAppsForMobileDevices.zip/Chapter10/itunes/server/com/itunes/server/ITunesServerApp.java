package com.itunes.server;

import com.itunes.server.*;

import java.io.*;

import java.net.*;
import java.util.*;

/**
 * ITunesServerApp
 * The class which is responsible for listening to incoming connections etc.
 */
public class ITunesServerApp {

	private ITunesController controller;
	
	// keep a list of all connected clients so we are able
	// send messages to all clients i.e. track info
	private Vector<ITunesClientThread> connectedClients;
	
	/**
	 * 
	 * @param port
	 */
	public ITunesServerApp(  int port ) {
		System.out.println( "ITunesSocketServer version 1.0" );
		ServerSocket server;

		// starts the itunes application automatically...
		controller = new ITunesController( this );
		
		// create the haspmap for storing the connected clients
		connectedClients = new Vector<ITunesClientThread>();
		
		try
		{
			server = new ServerSocket( port );
			System.out.println( "Server running on port: " + port );
			while( true )
			{
				Socket socket = server.accept();
				
				// hande incoming messages in a seperate thread...
				ITunesClientThread client = new ITunesClientThread ( this, socket );
				
				// add the client to the list of connected clients
				connectedClients.addElement( client );
				
				// start listening etc.
				client.start();
			}
		}
		catch(IOException ioe)
		{
				System.out.println( "Server error:" + ioe.getMessage() );
				controller.quitApplication();
		}
	}
	
	/**
	 * Forwards the incoming command to the itunes controller
	 * @param message
	 */
	public void doAction( String message )
	{
		controller.handleCommand( message );
	}
	
	/**
	 * Send the specified message to all connected clients...
	 * 
	 * @param message
	 */
	public synchronized void sendMessage( String message ) {
		Enumeration cc = connectedClients.elements();
		 while ( cc.hasMoreElements() ) {
			 ITunesClientThread client = (ITunesClientThread) cc.nextElement();
			 client.sendMessage( message + "\0" );
		 }
	}
	
	public static void main(String[] args) {
		int port = 888; 
		
		if( args.length != 0 ) {
			port = Integer.parseInt( args[0] );
		}
		ITunesServerApp server = new ITunesServerApp( port );
	}

}
