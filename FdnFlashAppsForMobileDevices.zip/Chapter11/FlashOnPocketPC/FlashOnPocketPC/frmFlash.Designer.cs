namespace FlashOnPocketPC
{
    partial class frmFlash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mnuMain;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuMain = new System.Windows.Forms.MainMenu();
            this.flashControl = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.mnuFileMain = new System.Windows.Forms.MenuItem();
            this.mnuFileOpen = new System.Windows.Forms.MenuItem();
            this.cdgOpen = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.MenuItems.Add(this.mnuFileMain);
            // 
            // flashControl
            // 
            this.flashControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flashControl.Location = new System.Drawing.Point(0, 0);
            this.flashControl.Name = "flashControl";
            this.flashControl.Size = new System.Drawing.Size(240, 268);
            this.flashControl.TabIndex = 0;
            this.flashControl.Text = "axShockwaveFlash1";
            this.flashControl.OnReadyStateChange += new AxShockwaveFlashObjects._IShockwaveFlashEvents_OnReadyStateChangeEventHandler(this.flashControl_OnReadyStateChange);
            this.flashControl.FSCommand += new AxShockwaveFlashObjects._IShockwaveFlashEvents_FSCommandEventHandler(this.flashControl_FSCommand);
            // 
            // mnuFileMain
            // 
            this.mnuFileMain.MenuItems.Add(this.mnuFileOpen);
            this.mnuFileMain.Text = "File";
            // 
            // mnuFileOpen
            // 
            this.mnuFileOpen.Text = "Open Movie...";
            this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
            // 
            // cdgOpen
            // 
            this.cdgOpen.Filter = "Flash movies|*.swf";
            // 
            // frmFlash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.flashControl);
            this.Menu = this.mnuMain;
            this.Name = "frmFlash";
            this.Text = "Flash on the PocketPC";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.frmFlash_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private AxShockwaveFlashObjects.AxShockwaveFlash flashControl;
        private System.Windows.Forms.MenuItem mnuFileMain;
        private System.Windows.Forms.MenuItem mnuFileOpen;
        private System.Windows.Forms.OpenFileDialog cdgOpen;

    }
}

