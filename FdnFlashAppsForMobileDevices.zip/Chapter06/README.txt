Chapter 6: Mobile Gaming

Inside this folder you will find several examples illustrating the concepts 
behind application development in Flash Lite 1.1 and 2.X.

The majority of these examples were designed to run on the Symbian standalone 
player device profile. They may work in other situations but when testing 
please be sure to select this profile if possible.

There are several sub-folders in this folder containing games that have several 
files to them, and also a couple of bonus files for you to try.

The BlackJack example is the most complex to get running. Instructions are included
at the end of the chapter. First of all you will need to have a Java JRE installed 
on your system, you can get this from http://java.com. On windows the easiest way to 
run the BlackJack server is to double click the included .bat files (such as 
run_server.bat). You can then test the example FLA.

NOTE: The samples are designed to run in the Flash Lite player (either on a 
device or in the Flash MX 2004 Professional or Flash 8 Professional IDE). For 
this reason certain functionality may not work when run in the web browser 
plugin or standalone desktop Flash Player.