Chapter 8: Flash Mobile Sound

Inside the Sound folder you will find the latest source for this chapter. 

Filenames starting with FL2 will only run under Flash Lite 2 enabled devices. 
Filenames starting with FL11 should run under both Flash Lite 1.1 and Flash 
Lite 2.X Players.

Your target device may vary in regards to sound support with Flash Lite. 
Please consult your device's documentation to determine which sound formats 
your device supports.

NOTE: The samples are designed to run in the Flash Lite player (either on a 
device or in the Flash MX 2004 Professional or Flash 8 Professional IDE). For 
this reason certain functionality may not work when run in the web browser 
plugin or standalone desktop Flash Player.