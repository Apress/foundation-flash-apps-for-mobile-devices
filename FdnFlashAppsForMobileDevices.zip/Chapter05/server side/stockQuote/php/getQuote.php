<?php
	// Include the nusoap library
	include("nusoap.php");
	
	// Symbol name to check
	$params = array("symbol" => $_GET["symbol"]);
	$sc = new soapclient("http://services.xmethods.net/soap/urn:xmethods-delayed-quotes.wsdl", true);
	$result = $sc->call("getQuote", $params);
	
	// Return result to Flash
	echo("result=" . $result);						
?>