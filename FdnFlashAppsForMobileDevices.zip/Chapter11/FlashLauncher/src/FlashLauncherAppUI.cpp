// INCLUDE FILES
#include <aknapp.h>
#include <aknappui.h>
#include <akndoc.h>
#include <apgcli.h>

#include "FlashLauncher.h"

// the relative path to the file to has to be opened 
// with the default application
_LIT( KBootstrapFileName, "\\documents\\flash\\myFlashFile.swf" );

void CFlashLauncherAppUi::ConstructL() {
  // session of the application server architecture
  RApaLsSession currSession; 
  TThreadId currThreadId;  // the threadid of the default application
  TFileName appPath;  // get the application name and the path
  TFileName bootstrapFileName;  // the actual bootstrap file

  CleanupClosePushL( currSession );

  // connect this client to the app arch. server
  User::LeaveIfError( currSession.Connect() );

  // get the drive letter from the application location
  appPath = Application()->AppFullName();
  bootstrapFileName = TParsePtrC( appPath ).Drive();

  // add the drive letter to the location of the bootstrap file
  bootstrapFileName.Append( KBootstrapFileName );

  // open the file using the default application associated with 
  // the mimetype of the bootstrap file
  //
  // when this command fails our application will be closed silently
  User::LeaveIfError( currSession.StartDocument(
         bootstrapFileName, currThreadId ) );

  // close the connection of this client with the app arch. server
  currSession.Close();
}

/**
 * Constructor
 */
CFlashLauncherAppUi::CFlashLauncherAppUi() {
}

/**
 * Destructor
 */
CFlashLauncherAppUi::~CFlashLauncherAppUi() {
}
