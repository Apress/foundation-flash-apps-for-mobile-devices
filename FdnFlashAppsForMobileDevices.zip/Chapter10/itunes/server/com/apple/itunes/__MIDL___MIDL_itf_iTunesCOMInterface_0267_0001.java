/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0267_0001 {

	public static final int ITPlayerStateStopped = 0;
	public static final int ITPlayerStatePlaying = 1;
	public static final int ITPlayerStateFastForward = 2;
	public static final int ITPlayerStateRewind = 3;
}
