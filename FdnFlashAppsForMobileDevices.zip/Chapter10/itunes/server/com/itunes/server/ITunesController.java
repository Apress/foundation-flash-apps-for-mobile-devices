package com.itunes.server;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.*;
import com.apple.itunes.*;

public class ITunesController {
	
	private ITunesServerApp server;
	private IiTunes iTunes;
	
	public class ITunesEvents
	{
		/**
		 * Event raised when a track gets played in iTunes
		 * 
		 * @param args
		 */
		public void OnPlayerPlayEvent(Variant[] args)
		{
			System.out.println( "OnPlayerPlayEvent()" );
			fireEvent();
		}
	}
	
	/**
	 * Initiates/Creates the controller class
	 * 
	 * @param server the application instance
	 */
	public ITunesController( ITunesServerApp server ) {
		this.server = server;
		initiateITunes();
	}
	
	/**
	 * Start iTunes by creating the COM object
	 */
	public void initiateITunes() {
		System.out.println( "Starting iTunes..." );
		
		ComThread.InitMTA( true );
		ActiveXComponent iTunesCom = new ActiveXComponent( "iTunes.Application" );
		Dispatch iTunesController = iTunesCom.getObject();
		iTunes = new IiTunes(iTunesController);
		
		//	Dispatch events.
		new DispatchEvents(iTunes, new ITunesEvents());
	}
	
	/**
	 * The currently playing track has been changed 
	 * from within the iTunes application
	 */
	public void fireEvent() {
		String xmlMessage = "";
		
		// get the current playing track information
		IITTrack currentTrack = iTunes.getCurrentTrack();
		xmlMessage = "<track artist=\"" + currentTrack.getArtist() +  "\">" + currentTrack.getName() + "</track>";
		
		// update the last output message to the xml message
		this.server.sendMessage( xmlMessage );
	}
	
	/**
	 * Forward the specified request to the itunes application...
	 * 
	 * @param command	the command to be executed by itunes
	 */
	public void handleCommand( String command )
	{
		if ( command.equals( "play" ) )
		{
			playTrack();
		}
		else if ( command.equals( "stop" ) )
		{
			stopTrack();
		}
		else if ( command.equals( "pause" ) )
		{
			pauseTrack();
		}
		else if ( command.equals( "next" ) )
		{
			nextTrack();
		}
		else if ( command.equals( "previous" ) )
		{
			previousTrack();
		} 
		else if ( command.equals( "quit" ) ) {
			quitApplication();
		}
		else if ( command.equals( "info" ) )
		{
			getTrackInfo();
		}
	}
	
	/**
	 * Play the next track
	 */
	public void nextTrack() {
		iTunes.nextTrack();
	}
	
	/**
	 * Play the previous track
	 */
	public void previousTrack() {
		iTunes.backTrack();
	}

	/**
	 * Play the currently playing or next track
	 */
	public void playTrack() {
		iTunes.play();
	}

	/**
	 * Pause the currently playing track
	 */
	public void pauseTrack() {
		iTunes.playPause();
	}

	/**
	 * Stop the currently playing track
	 */
	public void stopTrack() {
		iTunes.stop();
	}
	
	/**
	 * Exit the iTunes application
	 */
	public void quitApplication() {
		iTunes.quit();
		ComThread.Release();
	}

	/**
	 * Return the track info
	 *
	 */
	public void getTrackInfo() {
		fireEvent();
	}
}
