package com.itunes.server;

import java.io.*;
import java.net.*;

public class ITunesClientThread extends Thread {
	private BufferedReader input;
	private PrintWriter output;
	
	private char EOF = (char)0x00;
	
	private ITunesServerApp server;
	private Socket socket;
	
	/**
	 * 
	 * @param server	the server
	 * @param socket	the socket of the client thread
	 */
	public ITunesClientThread( ITunesServerApp server, Socket socket ) {
		this.server = server;
		this.socket = socket;
		
		try {
			output = new PrintWriter( socket.getOutputStream(), true );
			input = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
		}
		catch ( IOException ioe ) {
			try
			{
				System.out.println( "Server closing due to error: " + ioe.getMessage() );
				socket.close();
			}
			catch ( IOException e ) {
				System.out.println( "Server unable to close: " + e.getMessage() );
			}
		}
	}
	
	/**
	 * Send a message back to the client...
	 * 
	 * @param message the message to be send
	 */
	public void sendMessage( String message ) {
		System.out.println( "OUT: " + message );
		output.println( message + EOF );
	}
	
	/**
	 * Returns the socket of this client thread
	 */
	public Socket getSocket() {
		return socket;
	}
	
	/**
	 * Handle the incoming command
	 * 
	 * @param message the incoming message/command
	 */
	public void handleCommand( String message ) {
		System.out.println( "Incoming message: " + message );
		if ( server != null )
		{
			server.doAction( message );
		}
	}
	
	/**
	 * Running
	 */
	public void run() {
		char buffer[] = new char[1];
		
		try {
			while ( input.read( buffer, 0, 1 ) != -1 ) {
				String incomingMessage = "";
				
				// find the incoming comman request
				while( buffer[0] != '\0' ) {
					incomingMessage += buffer[0];
					input.read( buffer, 0, 1 );
				}
				
				// handle the received message
				handleCommand( incomingMessage );
			}
		}
		catch ( IOException ioe ) {
			System.out.println( "ERROR: Socket disconnected." );
		}
	}
}
