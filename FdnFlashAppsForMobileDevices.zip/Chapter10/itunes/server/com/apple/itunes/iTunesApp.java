/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public class iTunesApp extends IiTunes {

	public static final String componentName = "iTunesLib.iTunesApp";

	public iTunesApp() {
		super(componentName);
	}

	public iTunesApp(Dispatch d) {
		super(d);
	}
}
