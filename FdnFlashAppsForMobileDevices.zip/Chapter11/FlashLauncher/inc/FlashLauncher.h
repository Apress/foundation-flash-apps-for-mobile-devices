#ifndef __FLASHLAUNCHER_H__
#define __FLASHLAUNCHER_H__

// INCLUDES
#include <aknapp.h>
#include <aknappui.h>
#include <akndoc.h>
#include <apgcli.h>

// CLASS DECLARATION
class CFlashLauncherApp : public CAknApplication
    {
    public:
        TUid AppDllUid() const;

    protected:
        CApaDocument* CreateDocumentL();
    };

// CLASS DECLARATION
class CFlashLauncherAppUi : public CAknAppUi {
    public:
        void ConstructL();

        CFlashLauncherAppUi();

        virtual ~CFlashLauncherAppUi();
    public:
    private:
    };

// FORWARD DECLARATIONS
class CEikApplication;

// CLASS DECLARATION
class CFlashLauncherDocument : public CAknDocument
    {
    public:
        static CFlashLauncherDocument* NewL( CEikApplication& aApp );

        static CFlashLauncherDocument* NewLC( CEikApplication& aApp );

        virtual ~CFlashLauncherDocument();

    public:
         CEikAppUi* CreateAppUiL();

    private: 
        void ConstructL();

        CFlashLauncherDocument( CEikApplication& aApp );
    };
    
#endif // end of __FLASHLAUNCHER_H__