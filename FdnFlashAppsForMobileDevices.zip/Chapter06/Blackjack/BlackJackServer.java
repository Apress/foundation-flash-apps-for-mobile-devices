import java.io.*;
import java.net.*;

/**
 * Simple XMLSocket Server for Flash Lite 2.1
 * @author Richard Leggett www.richardleggett.co.uk
 */
 
public class BlackJackServer 
{
    
    public static void main( String args[] ) 
    {
        
        int port = 2048;
        ServerSocket server;
        
        try 
        {    
            server = new ServerSocket( port );
            System.out.println( "BlackJackServer running on port: " + port );
    
            while( true ) 
            {
              Socket socket = server.accept();
              System.out.println("Server.accept()");
              
              Dealer dealer = new Dealer( socket );
              dealer.start();
            }
        } 
        catch(IOException ioe) 
        {
            System.out.println( "Server error:" + ioe.getMessage() );
        }
        
    }
}