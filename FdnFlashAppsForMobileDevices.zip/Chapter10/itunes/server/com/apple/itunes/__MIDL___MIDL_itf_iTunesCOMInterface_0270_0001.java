/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0270_0001 {

	public static final int ITEventDatabaseChanged = 1;
	public static final int ITEventPlayerPlay = 2;
	public static final int ITEventPlayerStop = 3;
	public static final int ITEventPlayerPlayingTrackChanged = 4;
	public static final int ITEventUserInterfaceEnabled = 5;
	public static final int ITEventCOMCallsDisabled = 6;
	public static final int ITEventCOMCallsEnabled = 7;
	public static final int ITEventQuitting = 8;
	public static final int ITEventAboutToPromptUserToQuit = 9;
	public static final int ITEventSoundVolumeChanged = 10;
}
