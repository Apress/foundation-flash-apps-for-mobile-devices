/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0283_0001 {

	public static final int ITSourceKindUnknown = 0;
	public static final int ITSourceKindLibrary = 1;
	public static final int ITSourceKindIPod = 2;
	public static final int ITSourceKindAudioCD = 3;
	public static final int ITSourceKindMP3CD = 4;
	public static final int ITSourceKindDevice = 5;
	public static final int ITSourceKindRadioTuner = 6;
	public static final int ITSourceKindSharedLibrary = 7;
}
