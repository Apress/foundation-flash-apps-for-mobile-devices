/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface ITPlaylistPrintKind extends __MIDL___MIDL_itf_iTunesCOMInterface_0278_0003 {

}
