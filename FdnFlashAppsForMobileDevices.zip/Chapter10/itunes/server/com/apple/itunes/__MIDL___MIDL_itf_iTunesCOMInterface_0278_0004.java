/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0278_0004 {

	public static final int ITPlaylistSearchFieldAll = 0;
	public static final int ITPlaylistSearchFieldVisible = 1;
	public static final int ITPlaylistSearchFieldArtists = 2;
	public static final int ITPlaylistSearchFieldAlbums = 3;
	public static final int ITPlaylistSearchFieldComposers = 4;
	public static final int ITPlaylistSearchFieldSongNames = 5;
}
