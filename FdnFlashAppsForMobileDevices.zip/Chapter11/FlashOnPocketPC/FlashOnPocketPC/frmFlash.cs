using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FlashOnPocketPC
{
    public partial class frmFlash : Form
    {
        public frmFlash()
        {
            InitializeComponent();
        }

        /**
         * This event will be raised when the user clicks on the exit icon
         * on the top right side of the caption bar
         * 
         * @param sender        the sender object
         * @param e             the event arguments
         * 
         */
        private void frmFlash_Closing(object sender, CancelEventArgs e)
        {
            Application.Exit();
        }

        /**
         * This event gets raised each time the state of the control changes
         *
         */
        private void flashControl_OnReadyStateChange(object sender, AxShockwaveFlashObjects._IShockwaveFlashEvents_OnReadyStateChangeEvent e)
        {
            if ( e.newState == 4 )
            {
                flashControl.Play();
            }
        }

        /**
         * Handles all incoming FSCommand() commands received from the opened Flash movie
         * you should expand this method if you want to have support for more commands from within Flash.
         */
        private void flashControl_FSCommand(object sender, AxShockwaveFlashObjects._IShockwaveFlashEvents_FSCommandEvent e)
        {
            // The triggered FSCommand() in the Flash Movie
            string sCommand = e.command;

            switch (sCommand)
            {
                case "FileOpen":
                    flashControl.SetVariable( "$FSD", "Return result of the FileOpen command" );
                    break;

                case "WriteFile":
                    // forwards the request and the arguments to a dedicated method 
                    this.writeFile( e.command, e.args ); 
                    break;

                default:
                    // default return 
                    flashControl.SetVariable( "$FSD", "-1" );
                    break;
            }
        }

        /**
         * Handle the File Open menu item
         */
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            // the user has clicked on the File Open menu item in the main menu of the application
            // it's time to show the open file dialog, if available!
            cdgOpen.ShowDialog();
            if (cdgOpen.FileName != String.Empty )
            {
                flashControl.Movie = "file://" + cdgOpen.FileName;
            }
        }

        /**
         * The command which writes the content to the specified filename on the device
         */
        private void writeFile(string commandName, string parameters)
        {
            string[] params__ = parameters.Split(new char[] { '&' });
            string filename = params__[0].Split(new char[] { '=' })[1];
            string content = params__[1].Split(new char[] { '=' })[1];
            
            using (StreamWriter sw = new StreamWriter(filename))
            sw.Write(content);
        }
    }
}