// INCLUDE FILES
#include "FlashLauncher.h"

CFlashLauncherDocument* CFlashLauncherDocument::NewL( CEikApplication& aApp ) {
    CFlashLauncherDocument* self = NewLC( aApp );
    CleanupStack::Pop( self );
    return self;
}

CFlashLauncherDocument* CFlashLauncherDocument::NewLC( CEikApplication& aApp ) {
    CFlashLauncherDocument* self =
        new ( ELeave ) CFlashLauncherDocument( aApp );

    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
}

void CFlashLauncherDocument::ConstructL() {
    // No implementation required
}

CFlashLauncherDocument::CFlashLauncherDocument( CEikApplication& aApp ) : CAknDocument( aApp ) {
    // No implementation required
}

CFlashLauncherDocument::~CFlashLauncherDocument() {
    // No implementation required
}

CEikAppUi* CFlashLauncherDocument::CreateAppUiL() {
    // Create the application user interface, and return a pointer to it;
    // the framework takes ownership of this object
    return ( static_cast <CEikAppUi*> ( new ( ELeave )
                                        CFlashLauncherAppUi ) );
}
