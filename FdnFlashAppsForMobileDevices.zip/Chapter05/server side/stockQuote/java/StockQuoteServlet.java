import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import javax.xml.namespace.QName;

public class StockQuoteServlet extends HttpServlet 
{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException 
	{

		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
	
		try
        {
			String symbol = req.getParameter("symbol");
            String endpoint = "http://services.xmethods.net/soap/urn:xmethods-delayed-quotes";

            Service service = new Service();
            Call call = (Call) service.createCall();

            call.setTargetEndpointAddress(new java.net.URL(endpoint));
            call.setOperationName(new QName("getQuote"));
            
            Float ret = (Float) call.invoke(new Object[] { symbol });
            out.println("result=" + ret);
        } 
        catch (Exception e)
        {
            System.err.println(e.toString());
        }
	}
}