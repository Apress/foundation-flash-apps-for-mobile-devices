/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0280_0001 {

	public static final int ITUserPlaylistSpecialKindNone = 0;
	public static final int ITUserPlaylistSpecialKindPurchasedMusic = 1;
	public static final int ITUserPlaylistSpecialKindPartyShuffle = 2;
	public static final int ITUserPlaylistSpecialKindPodcasts = 3;
	public static final int ITUserPlaylistSpecialKindFolder = 4;
	public static final int ITUserPlaylistSpecialKindVideos = 5;
	public static final int ITUserPlaylistSpecialKindMusic = 6;
	public static final int ITUserPlaylistSpecialKindMovies = 7;
	public static final int ITUserPlaylistSpecialKindTVShows = 8;
	public static final int ITUserPlaylistSpecialKindAudiobooks = 9;
}
