/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface ITVisualSize extends __MIDL___MIDL_itf_iTunesCOMInterface_0267_0002 {

}
