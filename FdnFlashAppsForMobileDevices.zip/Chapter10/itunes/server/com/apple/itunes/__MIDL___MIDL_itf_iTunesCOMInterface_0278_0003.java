/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0278_0003 {

	public static final int ITPlaylistPrintKindPlaylist = 0;
	public static final int ITPlaylistPrintKindAlbumlist = 1;
	public static final int ITPlaylistPrintKindInsert = 2;
}
