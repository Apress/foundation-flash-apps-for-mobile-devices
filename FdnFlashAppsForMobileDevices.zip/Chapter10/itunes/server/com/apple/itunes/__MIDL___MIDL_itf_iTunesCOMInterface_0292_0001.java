/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0292_0001 {

	public static final int ITWindowKindUnknown = 0;
	public static final int ITWindowKindBrowser = 1;
	public static final int ITWindowKindPlaylist = 2;
	public static final int ITWindowKindEQ = 3;
	public static final int ITWindowKindArtwork = 4;
	public static final int ITWindowKindNowPlaying = 5;
}
