Chapter 7 - Flash Lite Mobile Entertainment Basics

All the example source code for this chapter is Flash Lite 1.1 specific. 

Your target device must also support Flash Lite wallpaper and screen saver 
modes for the content to work as intended (not all Flash Lite devices support 
these multimedia content types). Please consult your device documentation or 
check the supported features online to see if your target device supports
Flash Lite based wallpapers and screen savers.

NOTE: The samples are designed to run in the Flash Lite player (either on a 
device or in the Flash MX 2004 Professional or Flash 8 Professional IDE). For 
this reason certain functionality may not work when run in the web browser 
plugin or standalone desktop Flash Player.
