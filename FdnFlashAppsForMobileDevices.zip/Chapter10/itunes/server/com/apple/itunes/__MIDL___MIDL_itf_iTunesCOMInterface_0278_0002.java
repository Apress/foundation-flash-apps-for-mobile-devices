/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.sourceforge.net/projects/jacob-project */
package com.apple.itunes;

import com.jacob.com.*;

public interface __MIDL___MIDL_itf_iTunesCOMInterface_0278_0002 {

	public static final int ITPlaylistRepeatModeOff = 0;
	public static final int ITPlaylistRepeatModeOne = 1;
	public static final int ITPlaylistRepeatModeAll = 2;
}
