The Java example requires that you have downloaded the Apache Axis classes from:

  http://ws.apache.org/axis/

Apache AXIS provides an implementation of the SOAP v1.1 protocol enabling our servlet to make SOAP requests or create SOAP based webservices.  In this example our servlet uses the AXIS classes to create a connection to our Stock Quote service at XMethods.net and request a price for the given symbol.  My server is running Apache Tomcat 5.5, so in order to make these new classes available too all web applications, I have placed the jars in <tomcat-install>/common/lib directory.  If you are running a different server, please consult your documentation on making external classes accessible to web applications.

Compiling the servlet:
------------------------------
Included is a batch file for Windows that will execute the following command:

  javac StockQuoteServlet.java
  
This will produce our servlet .class file ready for deployment via your server's standard mechanism (e.g. placing in WEB-INF/classes).  All of the JAR files included with Apache Axis (found in <axis-install>/lib/) are required either in the global Java CLASSPATH environment variable, or specifically referenced in the above command using the -classpath flag in order for it to compile. Alternatively if you are using a Java IDE such as Eclipse, you can streamline this process by creating a Java library (Right click project > Properties > Build Path > Library) which contains all of the necessary JARs, and save yourself a lot of typing. At the very least you can create a batch/bash/command line file that will run the above command with all the required parameters.

I have also packaged the application up as a WAR (Web Application Archive) file for easy deployment (usually involves dropping the WAR in your webapps folder and restarting the server).