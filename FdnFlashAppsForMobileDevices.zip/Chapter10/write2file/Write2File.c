#include<stdio.h>
#include<string.h>

int main ( int argc, char *argv[] ) {
	// argc = total given arguments
	// argv = array with the argument values
	FILE *fp; // the file pointer
	char FILENAME[ 100 ]; // the filename
	char FILEDATA[ 255 ]; // the contents of the file
	strcpy( FILENAME, argv[1] ); // copy the value from args to FILENAME
	strcpy( FILEDATA, argv[2] ); // copy the value from args to FILEDATA

	// open the file with the given filename
	fp = fopen( FILENAME, "w" );

	// write the string to the file
	fputs( FILEDATA, fp );
	fclose( fp ); // close the file

	return 0;
}
