import java.io.*;
import java.net.*;

public class Dealer extends Thread
{
    private BufferedReader reader;
    private PrintWriter writer;
    private char EOF = (char)0x00;
    private int dealerHand;

 
    public Dealer( Socket socket )
    {
        try
        {
            writer = new PrintWriter( socket.getOutputStream(), true );
            reader = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
        } 
        catch (IOException ioe)
        {
            try
            {
                System.out.println( "Server closing due to error: " + ioe.getMessage() );
                socket.close();
            } 
            catch (IOException e)
            {
                System.out.println( "Server unable to close: " + e.getMessage() );
            }
        }

    }

    
    public void run()
    {
        char buffer[] = new char[1];
        String outputMsg;

        try
        {
            while( reader.read(buffer, 0, 1) != -1 )
            {
                String inputMsg = "";

                while( buffer[0] != '\0' )
                {
                    inputMsg += buffer[0];
                    reader.read( buffer, 0, 1 );
                }
   
                
                // Perform logic based on input
                if( inputMsg.equalsIgnoreCase("<msg type=\"helloDealer\" />") )
                {
                    
                    dealerHand = (int)Math.round( Math.random()*10 ) + 2;
                    int playerHand = (int)Math.round( Math.random()*17 ) + 4;
                    outputMsg = "<msg type='helloDealer'><dealerHand val='" + dealerHand + "' /><userHand val='" + playerHand + "' /></msg>";
                    
                }
                else if ( inputMsg.equalsIgnoreCase("<msg type=\"hit\" />") )
                {
                   
                    int value = (int)Math.round( Math.random()*10 ) + 2;
                    outputMsg = "<msg type='hit'><card val='" + value + "' /></msg>";
                    
                }
                else if ( inputMsg.equalsIgnoreCase("<msg type=\"stick\" />") )
                {
                 
                    while( dealerHand < 16 )
                    {
                        dealerHand += (int)Math.round( Math.random()*10 ) + 2;
                    }
                    
                    outputMsg = "<msg type='stick'><dealerHand val='" + dealerHand + "' /></msg>";
                    
                }
                else
                {
                    
                    outputMsg = "<msg>unknownCommand</msg>";
                    
                }
                
                
                System.out.println( "Input: " + inputMsg );
                System.out.println( "Output: " + outputMsg );
                
                writer.println( outputMsg + EOF );
            }

        } 
        catch (IOException ioe)
        {
            System.out.println("Error: Socket disconnected.");
        }
    }
}